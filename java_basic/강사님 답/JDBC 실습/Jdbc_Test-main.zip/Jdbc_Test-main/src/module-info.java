/**
 * 
 */
/**
 * @author user
 *
 */
module Jdbc_Test {
	requires java.sql;
}